1. sea-uninstall.bat
 This batch file can be run directly on the device.
2. sea-uninstall.intunewin
 This is the file to use with Intune, if initiating the uninstallation using Intune.